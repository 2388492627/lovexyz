﻿<?php
$auth_user = 'admin'; //用户名
$auth_pass = '123456'; //密码
?>
﻿<?php
/**
 * QQ挂机类API管理中心
**/
include './inc.php';
$title='QQ挂机类API管理中心';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
  <nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">导航按钮</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="./">QQ挂机类API管理中心</a>
      </div><!-- /.navbar-header -->
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
          <li><a href="./"><span class="glyphicon glyphicon-home"></span> 添加授权</a></li>
		  <li class="active"><a href="./list.php"><span class="glyphicon glyphicon-list"></span> 授权列表</a></li>
          <li><a href="./login.php?logout"><span class="glyphicon glyphicon-log-out"></span> 退出登陆</a></li>
        </ul>
      </div><!-- /.navbar-collapse -->
    </div><!-- /.container -->
  </nav><!-- /.navbar -->
<?php
if($my=='del'&&$_GET['url']){
	$url=daddslashes($_GET['url']);
	$data=file_get_contents($allowlist_file);
	$data=str_replace("\r\n".$url,'',$data);
	$data=str_replace("\n".$url,'',$data);
	if(file_put_contents($allowlist_file,$data))
		exit("<script language='javascript'>alert('成功修改授权列表！');window.location.href='./list.php';</script>");
	else
		exit("<script language='javascript'>alert('修改授权列表失败，确保有本地写入权限！');history.go(-1);</script>");
}
$data=file_get_contents($allowlist_file);
$allowurl=str_replace(array("\r\n", "\r", "\n"), "[br]",$data);
$allowurl=array_reverse(explode("[br]",$allowurl));
?>
  <div class="container" style="padding-top:50px;">
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>网址</th><th>操作</th></tr></thead>
          <tbody>
		  <?php
		  foreach($allowurl as $row){
		  echo '<tr><td><a href="'.$row.'" target="_blank">'.$row.'</a></td><td><a href="./list.php?my=del&url='.urlencode($row).'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此卡密吗？\');">删除</a></td></tr>';
		  }
		  ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
﻿<?php
/**
 * QQ挂机类API管理中心
**/
include './inc.php';
$title='QQ挂机类API管理中心';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
  <nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">导航按钮</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="./">QQ挂机类API管理中心</a>
      </div><!-- /.navbar-header -->
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
          <li class="active">
            <a href="./"><span class="glyphicon glyphicon-home"></span> 添加授权</a>
          </li>
		  <li><a href="./list.php"><span class="glyphicon glyphicon-list"></span> 授权列表</a></li>
          <li><a href="./login.php?logout"><span class="glyphicon glyphicon-log-out"></span> 退出登陆</a></li>
        </ul>
      </div><!-- /.navbar-collapse -->
    </div><!-- /.container -->
  </nav><!-- /.navbar -->
<?php
if(isset($_POST['url'])){
	$url=daddslashes($_POST['url']);
	if(strpos($url,'http')===false)
		exit("<script language='javascript'>alert('站点网址必须带有http://和结尾的/');history.go(-1);</script>");
	$data=file_get_contents($allowlist_file);
	$data=$data."\r\n".$url;
	if(file_put_contents($allowlist_file,$data))
		exit("<script language='javascript'>alert('成功添加授权！');history.go(-1);</script>");
	else
		exit("<script language='javascript'>alert('添加授权失败，确保有本地写入权限！');history.go(-1);</script>");
}
?>
  <div class="container" style="padding-top:50px;">
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
      <div class="panel panel-primary">
        <div class="panel-heading"><h3 class="panel-title">添加站点授权</h3></div>
        <div class="panel-body">
          <form action="./" method="post" class="form-horizontal" role="form">
            <div class="input-group">
              <span class="input-group-addon">授权的站点</span>
              <input type="text" name="url" value="" class="form-control" placeholder="http://www.qqzzz.net/" autocomplete="off" required/>
            </div><br/>
            <div class="form-group">
              <div class="col-sm-12"><input type="submit" value="添加" class="btn btn-primary form-control"/></div>
            </div>
          </form>
        </div>
        <div class="panel-footer">
          <span class="glyphicon glyphicon-info-sign"></span> 站点网址必须带有http://和结尾的/，需精确到文件夹。</div>
      </div>
    </div>
  </div>